import 'bulma/css/bulma.css';
import './App.scss';
import { useState } from 'react';

export const goodsFromServer = [
  'Dumplings',
  'Carrot',
  'Eggs',
  'Ice cream',
  'Apple',
  'Bread',
  'Fish',
  'Honey',
  'Jam',
  'Garlic',
];

export const App = () => {
  const [newsGoods, setNewsGoods] = useState(goodsFromServer);
  const [activeSort, setActiveSort] = useState('');
  const [previousSort, setPreviousSort] = useState('');

  return (
  <div className="section content">
      <div className="buttons">
      <button type="button" className={`button is-info ${activeSort === "alphabetical" ? "" : "is-light"}`} onClick={() => {
        if (activeSort === "reverse") {
        setNewsGoods([...goodsFromServer].sort());
        setActiveSort("alphabetical")
        } else {
          setNewsGoods([...goodsFromServer].sort());
          setActiveSort("alphabetical")
        }}}>
          Sort alphabetically
      </button>

      <button type="button" className={`button is-success ${activeSort === "length" ? "" : "is-light"}`}
      onClick={() => {setNewsGoods([...newsGoods].sort((a, b) => a.length - b.length));setActiveSort("length")}}>
        Sort by length
      </button>

      <button type="button" className={`button is-warning ${activeSort === "reverse" ? "" : "is-light"}`}
      onClick={() => {setNewsGoods([...newsGoods].reverse());
        if (activeSort !== "reverse") {
          setPreviousSort(activeSort);
          setActiveSort("reverse");
        } else {
        setActiveSort(previousSort)
        }}}>
        Reverse
      </button>

      { activeSort !== '' && (
      <button type="button" className="button is-danger is-light"
      onClick={() => {setNewsGoods(goodsFromServer);setActiveSort('')}}>
        Reset
      </button>
      )}
    </div>

    <ul>
    {newsGoods.map((newsProducts) => (
        <li data-cy="Good" key={newsProducts}>
          {newsProducts}
        </li>
    ))}
    </ul>
  </div>
  )
};
